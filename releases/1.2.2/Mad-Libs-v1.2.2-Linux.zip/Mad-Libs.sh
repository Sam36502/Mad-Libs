#!/bin/bash
java -jar ./Mad-Libs.jar